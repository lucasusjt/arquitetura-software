package Exercicio6_1;

public class MensagemDomingo implements MensagemDoDia {
	public void imprimir() {
		System.out.println("Hoje � domingo.");
	}
}
